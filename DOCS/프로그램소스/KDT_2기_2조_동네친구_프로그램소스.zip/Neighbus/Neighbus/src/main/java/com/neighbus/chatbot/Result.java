package com.neighbus.chatbot;

public record Result (
    String type,
    String result
) {}
