# 관리자 계정 설정 가이드

## 📋 개요

Neighbus 프로젝트의 관리자 기능 테스트를 위한 설정 가이드입니다.

---

## 🔑 관리자 계정 정보

### 기본 관리자 계정
- **Username**: `Admin`
- **Password**: `12345`
- **Grade**: `0` (관리자 등급)

### 관리자 권한
- Grade가 `0`인 사용자는 자동으로 `ROLE_ADMIN` 권한을 받습니다
- 로그인 시 자동으로 관리자 대시보드(`/admin`)로 이동합니다

---

## 🚀 빠른 시작

### 1. 애플리케이션 실행

```bash
./gradlew bootRun
```

### 2. 관리자 로그인

1. 브라우저에서 http://localhost:8080/account/login 접속
2. 로그인 정보 입력:
   - Username: `Admin`
   - Password: `12345`
3. 로그인 버튼 클릭
4. 자동으로 http://localhost:8080/admin 페이지로 이동

---

## 🛠️ 새로운 관리자 계정 만들기

### 방법 1: 기존 계정을 관리자로 변경

DB에서 해당 계정의 `grade`를 `0`으로 변경:

```bash
mysql -u root -p1234 neighbus -e "UPDATE users SET grade = 0 WHERE username = '사용자이름';"
```

### 방법 2: 새 관리자 계정 직접 생성

#### Step 1: 비밀번호 암호화

원하는 비밀번호를 암호화:

```bash
./gradlew encodePassword --args="원하는비밀번호"
```

출력 예시:
```
원본 비밀번호: 원하는비밀번호
암호화된 비밀번호:
{bcrypt}$2a$10$xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

========================================
아래 SQL을 복사해서 MySQL에서 실행하세요:
========================================

UPDATE users
SET password = '{bcrypt}$2a$10$xxxxx...',
    grade = 0
WHERE username = 'admin';
```

#### Step 2: DB에 계정 생성 또는 업데이트

**새 계정 생성:**
```sql
INSERT INTO users (
    name, username, password, city, address, phone, email,
    image, grade, birth, sex, user_uuid, nickname
) VALUES (
    '관리자',
    'admin',
    '{bcrypt}$2a$10$xxxxx...',  -- 위에서 생성한 암호화된 비밀번호
    1,
    '관리자 주소',
    '010-0000-0000',
    'admin@example.com',
    'default.jpg',
    0,  -- 관리자 등급
    '990101',
    'M',
    UUID(),
    'Admin'
);
```

**기존 계정 업데이트:**
```bash
mysql -u root -p1234 neighbus -e "UPDATE users SET password = '{bcrypt}\$2a\$10\$xxxxx...', grade = 0 WHERE username = '사용자이름';"
```

---

## 🔍 관리자 기능 테스트

### 접근 가능한 관리자 페이지

1. **관리자 대시보드**: http://localhost:8080/admin
2. **사용자 관리**: http://localhost:8080/admin/users
3. **시스템 설정**: http://localhost:8080/admin/settings

### 권한 확인

일반 사용자(grade != 0)로 `/admin` 접속 시:
- **403 Forbidden** 에러 발생
- 접근 거부됨

관리자(grade = 0)로 접속 시:
- 정상 접근 가능
- 관리자 대시보드 표시

---

## ⚙️ 설정 정보

### Grade 시스템

| Grade | 권한 | 설명 |
|-------|------|------|
| 0 | ROLE_ADMIN | 관리자 권한 (모든 기능 접근 가능) |
| 1+ | ROLE_USER | 일반 사용자 권한 |

### 로그인 후 리다이렉트 규칙

- **Grade 0 (관리자)**: 자동으로 `/admin`으로 이동
- **Grade 1+ (일반 사용자)**: `/` 메인 페이지로 이동

---

## 🐛 문제 해결

### 로그인이 안 될 때

1. **DB에 계정이 있는지 확인:**
```bash
mysql -u root -p1234 neighbus -e "SELECT username, grade, SUBSTRING(password, 1, 30) FROM users WHERE username = 'Admin';"
```

2. **비밀번호 형식 확인:**
   - 비밀번호가 `{bcrypt}$2a$10$...` 형태로 시작해야 함
   - 아니면 다시 암호화해서 업데이트

3. **Grade 확인:**
   - 관리자 권한을 받으려면 `grade = 0`이어야 함

### 관리자 페이지 접근이 안 될 때

1. **로그 확인:**
   - 터미널에서 `>>> 관리자 로그인 감지!` 메시지가 나오는지 확인
   - `Grade: 0` 로그가 나오는지 확인

2. **Grade 재확인:**
```bash
mysql -u root -p1234 neighbus -e "UPDATE users SET grade = 0 WHERE username = 'Admin';"
```

### 비밀번호를 잊었을 때

비밀번호를 `12345`로 초기화:

```bash
mysql -u root -p1234 neighbus -e "UPDATE users SET password = '{bcrypt}\$2a\$10\$qJtochcv.8xYjzhroZFEkeoscTYjy5lI1hELBSkUcTqEiB7K1LoFK', grade = 0 WHERE username = 'Admin';"
```

---

## 📝 참고 사항

### 보안

- 프로덕션 환경에서는 반드시 강력한 비밀번호 사용
- 기본 관리자 계정(`Admin/12345`)은 테스트용
- 실제 배포 전 비밀번호 변경 필수

### 파일 위치

- **관리자 권한 설정**: `src/main/java/com/neighbus/account/AccountDTO.java:143`
- **로그인 핸들러**: `src/main/java/com/neighbus/config/CustomAuthenticationSuccessHandler.java`
- **Security 설정**: `src/main/java/com/neighbus/SecurityConfig.java:37,72`
- **관리자 페이지**: `src/main/resources/templates/admin/`

### 데이터베이스

- **테이블**: `users`
- **관리자 구분**: `grade = 0`
- **비밀번호 암호화**: bcrypt

---

## 📞 문의

문제가 발생하면 개발팀에 문의하세요.
